export const handler = async (event) => {
  const request = event.Records[0].cf.request;
  const host = (request.headers['host'] || [{}])[0].value || '';

  if (host === 'admin.my-saloon.online') {
    request.origin.s3.domainName = 'my-saloon-super-admin-web.s3.eu-north-1.amazonaws.com';
    request.origin.s3.path = '';
    request.headers['host'] = [{ key: 'Host', value: 'my-saloon-super-admin-web.s3.eu-north-1.amazonaws.com' }];
  } else {
    request.origin.s3.domainName = 'my-saloon-public-web.s3.eu-north-1.amazonaws.com';
    request.origin.s3.path = '';
    request.headers['host'] = [{ key: 'Host', value: 'my-saloon-public-web.s3.eu-north-1.amazonaws.com' }];
  }

  if (!request.uri.match(/\.(js|css|png|jpg|jpeg|svg|ico|woff2?|json|map|webp|gif)$/)) {
    request.uri = '/index.html';
  }

  return request;
};
